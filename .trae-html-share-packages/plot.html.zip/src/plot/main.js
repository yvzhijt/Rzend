// 独立绘图窗口：清晰绘制 + 滚轮缩放 + 拖动平移
const COLORS = ['#0072bd', '#d95319', '#77ac30', '#7e2f8e', '#edb120', '#4dbeee'];
const PAD = { l: 64, r: 24, t: 32, b: 48 };

const canvas = document.getElementById('plot-canvas');
const wrap = document.getElementById('plot-wrap');
const legend = document.getElementById('legend');
const caption = document.getElementById('caption');
const ctx = canvas.getContext('2d');

let payload = { title: 'Figure', series: [] };
let view = null;
let W = 0;
let H = 0;
let lastVersion = null;
let drag = null;

/* ---------------- 数据 ---------------- */

function readPayload() {
  const raw = localStorage.getItem('rzend:plot');
  if (!raw) return false;
  try {
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.series)) return false;
    payload = { title: data.title || 'Figure', series: data.series };
    return true;
  } catch {
    return false;
  }
}

function dataBounds() {
  let xmin = Infinity, xmax = -Infinity, ymin = Infinity, ymax = -Infinity;
  payload.series.forEach((s) => {
    const n = Math.min(s.xs?.length || 0, s.ys?.length || 0);
    for (let i = 0; i < n; i += 1) {
      const x = s.xs[i];
      const y = s.ys[i];
      if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
      if (x < xmin) xmin = x;
      if (x > xmax) xmax = x;
      if (y < ymin) ymin = y;
      if (y > ymax) ymax = y;
    }
  });
  if (!Number.isFinite(xmin) || !Number.isFinite(ymin)) return null;
  if (xmin === xmax) { xmin -= 1; xmax += 1; }
  const span = ymax - ymin || 1;
  return { xmin, xmax, ymin: ymin - span * 0.08, ymax: ymax + span * 0.08 };
}

/* ---------------- 刻度与格式化 ---------------- */

function niceStep(span, target) {
  const raw = span / target;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const n = raw / mag;
  const mult = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return mag * mult;
}

function makeTicks(min, max, target) {
  const step = niceStep(max - min, target);
  const first = Math.ceil(min / step - 1e-9) * step;
  const out = [];
  const count = Math.floor((max - first) / step + 1e-9);
  for (let i = 0; i <= count; i += 1) out.push({ v: first + step * i, step });
  return out;
}

const SI = [
  [1e9, 'G'], [1e6, 'M'], [1e3, 'k'], [1, ''],
  [1e-3, 'm'], [1e-6, 'µ'], [1e-9, 'n'], [1e-12, 'p'], [1e-15, 'f'],
];

function fmtNum(v, step) {
  if (Math.abs(v) < 1e-15) return '0';
  let scale = 1e-15;
  let suffix = 'f';
  for (const [s, u] of SI) {
    if (Math.abs(v) >= s) { scale = s; suffix = u; break; }
  }
  const digits = Math.max(0, Math.min(4, -Math.floor(Math.log10(step / scale) + 1e-9)));
  const text = (v / scale).toFixed(digits);
  return `${text.replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1')}${suffix}`;
}

/* ---------------- 绘制 ---------------- */

function fitCanvas() {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  W = Math.max(1, Math.round(rect.width));
  H = Math.max(1, Math.round(rect.height));
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function renderLegend() {
  const named = payload.series.filter((s) => s.name);
  legend.innerHTML = named.map((s) => {
    const i = payload.series.indexOf(s);
    const color = COLORS[i % COLORS.length];
    return `<div class="lg-item"><span class="lg-dot" style="background:${color}"></span><span>${s.name}</span></div>`;
  }).join('');
  legend.style.display = named.length ? 'flex' : 'none';
}

function draw() {
  fitCanvas();
  if (!view) view = dataBounds();
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, W, H);
  caption.textContent = payload.title;
  renderLegend();

  if (!view) {
    ctx.fillStyle = '#8a9199';
    ctx.font = '13px "Segoe UI", "PingFang SC", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('没有可绘制的数据', W / 2, H / 2);
    return;
  }

  const pw = Math.max(10, W - PAD.l - PAD.r);
  const ph = Math.max(10, H - PAD.t - PAD.b);
  const sx = (x) => PAD.l + ((x - view.xmin) / (view.xmax - view.xmin)) * pw;
  const sy = (y) => PAD.t + ph - ((y - view.ymin) / (view.ymax - view.ymin)) * ph;

  const xt = makeTicks(view.xmin, view.xmax, Math.max(3, Math.round(pw / 85)));
  const yt = makeTicks(view.ymin, view.ymax, Math.max(3, Math.round(ph / 50)));

  // 网格
  ctx.lineWidth = 1;
  ctx.strokeStyle = '#eef0f2';
  xt.forEach(({ v }) => {
    const x = Math.round(sx(v)) + 0.5;
    ctx.beginPath();
    ctx.moveTo(x, PAD.t);
    ctx.lineTo(x, PAD.t + ph);
    ctx.stroke();
  });
  yt.forEach(({ v }) => {
    const y = Math.round(sy(v)) + 0.5;
    ctx.beginPath();
    ctx.moveTo(PAD.l, y);
    ctx.lineTo(PAD.l + pw, y);
    ctx.stroke();
  });

  // 零线
  if (view.ymin < 0 && view.ymax > 0) {
    ctx.strokeStyle = '#d6dade';
    const y = Math.round(sy(0)) + 0.5;
    ctx.beginPath();
    ctx.moveTo(PAD.l, y);
    ctx.lineTo(PAD.l + pw, y);
    ctx.stroke();
  }

  // 坐标轴
  ctx.strokeStyle = '#b9c0c7';
  ctx.beginPath();
  ctx.moveTo(PAD.l + 0.5, PAD.t);
  ctx.lineTo(PAD.l + 0.5, PAD.t + ph + 0.5);
  ctx.lineTo(PAD.l + pw, PAD.t + ph + 0.5);
  ctx.stroke();

  // 刻度标签
  ctx.fillStyle = '#5a6268';
  ctx.font = '11px Consolas, "Courier New", monospace';
  ctx.textAlign = 'right';
  yt.forEach(({ v, step }) => {
    ctx.fillText(fmtNum(v, step), PAD.l - 10, sy(v) + 4);
  });
  ctx.textAlign = 'center';
  xt.forEach(({ v, step }) => {
    ctx.fillText(fmtNum(v, step), sx(v), PAD.t + ph + 20);
  });

  // 曲线
  ctx.save();
  ctx.beginPath();
  ctx.rect(PAD.l, PAD.t, pw, ph);
  ctx.clip();
  payload.series.forEach((s, si) => {
    const n = Math.min(s.xs?.length || 0, s.ys?.length || 0);
    if (!n) return;
    ctx.strokeStyle = COLORS[si % COLORS.length];
    ctx.lineWidth = 1.6;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    let started = false;
    const stride = Math.max(1, Math.floor(n / (pw * 2)));
    for (let i = 0; i < n; i += stride) {
      const x = s.xs[i];
      const y = s.ys[i];
      if (!Number.isFinite(x) || !Number.isFinite(y)) {
        started = false;
        continue;
      }
      const px = sx(x);
      const py = sy(y);
      if (!started) {
        ctx.moveTo(px, py);
        started = true;
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.stroke();
  });
  ctx.restore();
}

/* ---------------- 交互 ---------------- */

function applyData(force = false) {
  const version = localStorage.getItem('rzend:plot:v');
  if (!force && version === lastVersion) return;
  lastVersion = version;
  if (!readPayload()) return;
  view = null;
  draw();
}

canvas.addEventListener('wheel', (e) => {
  if (!view) return;
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;
  const pw = Math.max(10, W - PAD.l - PAD.r);
  const ph = Math.max(10, H - PAD.t - PAD.b);
  const fx = Math.min(1, Math.max(0, (mx - PAD.l) / pw));
  const fy = Math.min(1, Math.max(0, (my - PAD.t) / ph));
  const cx = view.xmin + fx * (view.xmax - view.xmin);
  const cy = view.ymax - fy * (view.ymax - view.ymin);
  const k = Math.exp(e.deltaY * 0.0012);
  if (!e.altKey) {
    view.xmin = cx + (view.xmin - cx) * k;
    view.xmax = cx + (view.xmax - cx) * k;
  }
  if (!e.shiftKey) {
    view.ymin = cy + (view.ymin - cy) * k;
    view.ymax = cy + (view.ymax - cy) * k;
  }
  draw();
}, { passive: false });

canvas.addEventListener('pointerdown', (e) => {
  if (!view) return;
  drag = { x: e.clientX, y: e.clientY, view: { ...view } };
  canvas.setPointerCapture(e.pointerId);
  canvas.classList.add('dragging');
});

canvas.addEventListener('pointermove', (e) => {
  if (!drag) return;
  const pw = Math.max(10, W - PAD.l - PAD.r);
  const ph = Math.max(10, H - PAD.t - PAD.b);
  const dx = ((e.clientX - drag.x) / pw) * (drag.view.xmax - drag.view.xmin);
  const dy = ((e.clientY - drag.y) / ph) * (drag.view.ymax - drag.view.ymin);
  view = {
    xmin: drag.view.xmin - dx,
    xmax: drag.view.xmax - dx,
    ymin: drag.view.ymin + dy,
    ymax: drag.view.ymax + dy,
  };
  draw();
});

canvas.addEventListener('pointerup', () => {
  drag = null;
  canvas.classList.remove('dragging');
});

canvas.addEventListener('dblclick', () => {
  view = dataBounds();
  draw();
});

document.getElementById('reset').addEventListener('click', () => {
  view = dataBounds();
  draw();
});

window.addEventListener('storage', (e) => {
  if (e.key === 'rzend:plot' || e.key === 'rzend:plot:v') applyData(true);
});

new ResizeObserver(() => draw()).observe(wrap);
applyData(true);
setInterval(() => applyData(false), 700);
